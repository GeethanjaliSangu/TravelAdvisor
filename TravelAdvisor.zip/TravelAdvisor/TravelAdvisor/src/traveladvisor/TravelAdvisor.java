/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;


import java.util.Scanner;
public class TravelAdvisor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int choice=1;
        System.out.println("***Welcome to Travel Advisor***");
        Scanner input = new Scanner(System.in);
        while(choice!=0){
            System.out.println();
            System.out.println("****Please choose one of our options:****");
            System.out.println("1: To login");
            System.out.println("2: To register yourself with us!!");
            System.out.println("0: To exit this and travel!!");
            choice = input.nextInt();
            
            switch(choice){
                case 1:
                    System.out.println();
                    System.out.println("Please select one of the options below:");
                    System.out.println("1: To login as Admin");
                    System.out.println("2: To login as User");
                    int login_choice = input.nextInt();
                    if(login_choice==1){

                        Register.Login();
                    }
                    else if(login_choice==2){
                        Register.Login();
                    }
                    else{
                        System.out.println("Please choose valid option");
                    }
                    break;
                case 2:
                    Register.createUserAccount();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Incorrect input. Please try again!");
                    break;
                        
            }
        }
        // TODO code application logic here
    }
    
}
