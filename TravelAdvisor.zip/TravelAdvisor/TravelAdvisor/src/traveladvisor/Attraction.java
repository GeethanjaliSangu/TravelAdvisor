/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
public class Attraction {
    /* String att_name;
    String att_Description;
    String State;
    String city;
    String tag;
    */
    static Scanner input = new Scanner(System.in);
    private static DataStorage data = new SQL_Database();
    public static void createAttraction(String id){
        String user=id;
        String att_name;
        while(true){
            System.out.println("Please enter name of the atraction");
            att_name = input.nextLine();
            if(!(UniqueAttraction(att_name))){
                System.out.println("Attraction name already exists. Please select other name");
            }
            else{
                break;
            }
        }
        System.out.println("Please explain the attraction in few words");
        String att_desc = input.nextLine();
        System.out.println("Please enter city of the attraction");
        String city = input.nextLine();
        System.out.println("Please enter state of the attraction");
        String state = input.nextLine();
        System.out.println("Please enter a tag for the attraction");
        String tag = input.nextLine();        
        data.createAttraction(user, att_name, att_desc, city, state, tag);
        User.MainMenu(id);
    }
    
    public static void postreview(String attr_name, String user){
        String comment="";
        System.out.println("Please enter your review comments: ");
        comment = input.nextLine();
        System.out.println("Please rate the attraction from 1 of 5 (5 being the highest):");
        float score = input.nextFloat();
        Date date = new Date();
        String d = date.toString();
        data.postreview(attr_name, user, score, comment, d);
        data.updatescore(score, attr_name);
    }
    
    public static boolean UniqueAttraction(String attname){
              ArrayList<String> allattractionnames = SQL_Database.allAttractions();
              for(String var:allattractionnames)
              {
                  if(var.equals(attname))
                  {
                      return false;
                  }
              }
              return true;           
    }
    
}
