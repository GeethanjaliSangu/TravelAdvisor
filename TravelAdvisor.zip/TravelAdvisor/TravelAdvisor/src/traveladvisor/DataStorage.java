/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;
public abstract interface DataStorage {
    void createAccount(String name, String userid, String pwd, String tag1, String tag2);
    void createAttraction(String user, String name, String desc, String city, String state, String tag);
    void Login(String id, String pwd);
    void displayUsers();
    void pendingAttractions();
    void approvedAttractions();
    void approve(String att_name);
    void search(String searchtag);
    void displayattraction(String att_name, String user);
    void postreview(String att_name, String user_id, float score, String comments, String d);
    void updatescore(float new_score, String att_name);
    void addfavattr(String att_name, String user);
    void displayfavattr(String user);
    void youmaylike(String user);
}
