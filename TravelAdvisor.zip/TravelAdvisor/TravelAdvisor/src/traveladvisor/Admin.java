/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;

import java.util.Scanner;
public class Admin extends Person{
    
    public Admin(String n, String us, String pwd){
        super(n,us,pwd);
    }
    static Scanner selection = new Scanner(System.in);   
    private static DataStorage data = new SQL_Database();
    public static void AdminMenu(){
        System.out.println("Please select one of the options below");
        System.out.println("1: To view all the users");
        System.out.println("2: To view all the Approved Attractions");
        System.out.println("3: To view Attractions that are pending for approval");
        System.out.println("4: To Approve attraction");
        System.out.println("0: To logout");
        String option = selection.nextLine();
        
        switch(option){
            case "1":
                data.displayUsers();
                Admin.AdminMenu();
                break;
            case "2":
                data.approvedAttractions();
                Admin.AdminMenu();
                break;
            case "3":
                data.pendingAttractions();
                Admin.AdminMenu();
                break;   
            case "4":
                System.out.println("Please enter attraction name you would like to approve");
                String att_name = selection.nextLine();
                data.approve(att_name);
                Admin.AdminMenu();
                break;
            case "0":
                break;
            
                
        }
        
    }
}
