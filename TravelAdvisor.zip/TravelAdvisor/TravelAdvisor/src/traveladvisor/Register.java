/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;

import java.util.ArrayList;
import java.util.Scanner;
public class Register {
    static Scanner details = new Scanner(System.in);
    
    private static DataStorage data = new SQL_Database();
    public static void  createUserAccount(){
        String user_id="";
        String pwd="";
        System.out.println("Please enter your name");
        String name = details.nextLine();
        System.out.println("Please enter unique User ID(One lower, one upper, one digit and 3-10 chars)");
        while(true){
            
            user_id = details.nextLine();
            // Validating if minimum requirements are met for ID
            // String validateuserid="^[a-zA-Z]{3,10}$"; // not working for all lowercase scenario, working for length
            String validateuserid = "((?=.*[a-z])(?=.*[0-9])(?=.*[A-Z]).{3,10})";            
            if(!(user_id.matches(validateuserid))){
                System.out.println("Please enter User ID that satisfy min req.");
            }
            else{
                if(!UniqueID(user_id)){
                    System.out.println("ID already taken. Please try another ID");
                }
                else{
                    break;
                }    
            }
        }        
        while(true){
        System.out.println("Please enter password");
        pwd = details.nextLine();
        if(pwd.equalsIgnoreCase(user_id)){
            System.out.println("Id and password cannot be same");
        }
        else
            break;
        }        
        System.out.println("Let us know what you are interested in by entering 2 tags: ");
        System.out.println("Please enter tag1");
        String tag1 = details.nextLine();
        System.out.println("Please enter tag2");
        String tag2 = details.nextLine(); 
        data.createAccount(name, user_id, pwd, tag1, tag2);    
    }
    
    public static void Login(){
        System.out.println("Please enter you User ID");
        String login_id = details.next();
        System.out.println("Please enter you Password");
        String login_pwd = details.next();
        if(login_id.equals("admin")&& login_pwd.equals("admin")){
            Admin.AdminMenu();
        }
        else{
            data.Login(login_id, login_pwd);   
        }
        
    }
    public static boolean UniqueID(String userid){
              ArrayList<String> allUserID = SQL_Database.allUsers();
              for(String var:allUserID)
              {
                  if(var.equals(userid))
                  {
                      
                      return false;
                  }
              }
              return true;           
    }
}
