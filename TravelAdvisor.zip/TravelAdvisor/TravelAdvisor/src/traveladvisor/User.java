/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;

import java.util.ArrayList;
import java.util.Scanner;
public class User extends Person {
    private String tag1;
    private String tag2;
    private static DataStorage data = new SQL_Database();
    public User(String n, String us, String pwd, String t1, String t2){
        super(n,us,pwd);
        tag1=t1;
        tag2=t2;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }
    
    public static void MainMenu(String id){
        Scanner input = new Scanner(System.in);
        String user = id;
        System.out.println();
        System.out.println("Places you may like bases on your tags");
        data.youmaylike(user);
        System.out.println("****Please select one the options****");
        System.out.println("1: To view all attractions");
        System.out.println("2: To view specific attraction");
        System.out.println("3: To create a attraction");
        System.out.println("4: To search attractions");
        System.out.println("5: To review attraction");
        System.out.println("6: To view your favorite places");
        System.out.println("0: To Logout");
        String option = input.nextLine();
        switch(option){
            case "1":
                // View all Attractions
                data.approvedAttractions();
                System.out.println();
                User.MainMenu(user);
                break;
            case "2":
                System.out.println("Please enter the name of the attraction you want to view");
                String attr_name = input.nextLine();
                data.displayattraction(attr_name,user);
                User.MainMenu(user);
                break;
            case "3":
                // Create Attraction
                Attraction.createAttraction(user);
                User.MainMenu(user);
                break;
            case "4":
                //Search attractions
                System.out.println("Please enter a tag/city name to search attraction");
                String searchtag = input.nextLine();
                data.search(searchtag);
                System.out.println("Please enter name of the attraction to view details");
                String att_name = input.nextLine();
                data.displayattraction(att_name,user);
                
                break;
                // User.MainMenu(user);
            case "5":
                // Review attraction
                System.out.println("Please enter name of the attraction you want to review");
                String attr_review = input.nextLine();
                Attraction.postreview(attr_review,user);
                // data.postreview(attr_review, user);
                User.MainMenu(user);
                break;
            case "6":
                data.displayfavattr(user);
            case "0":
                // logout
                break;
        }
        
    }
    
    
}
