/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traveladvisor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import static jdk.nashorn.internal.objects.NativeString.substr;
public class SQL_Database implements DataStorage{
     static final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/sangus1652?useSSL=false";
     static final String db_id = "sangus1652";
     static final String db_psw = "1847713";
     Connection connection = null;
     Statement statement = null;
     static Connection connect = null;
     static Statement stm = null;
     Scanner input = new Scanner(System.in);   
    @Override
    public void createAccount(String name, String userid, String pwd, String tag1, String tag2){
          /*  final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
            final String db_id = "kesaniv1536";
            final String db_psw = "1847246";
            Connection connection = null;
            Statement statement = null;
            // ResultSet resultSet = null;*/
        try
        {
            
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            int r = statement.executeUpdate("insert into user values"
                        + "('" + name + "', '" + userid + "', '" + pwd + "', '" + tag1 + "', '"
                        + tag2 +"')");
                System.out.println("Account creation successful!");
                System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 // resultSet.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    @Override
    public void createAttraction(String user, String name, String desc, String city, String state, String tag){
     /* final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
            final String db_id = "kesaniv1536";
            final String db_psw = "1847246";
            Connection connection = null;
            Statement statement = null;
            // ResultSet resultSet = null;*/
        try
        {
            
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            /* int r = statement.executeUpdate("insert into attractions values" + "('" + name + "', '"
                        + "', '" + city + "', '" + state + "', '" + desc + "', '" + tag + "', '"
                        + tag +"', 0, 'Pending', " + user+ "')"); */
            int r = statement.executeUpdate("insert into attractions values" + "('" +name+ "', '" + city+ "', '" + state+ 
						"', '" +desc+ "', '" +tag+ "', 0, 'pending', '" + user+ "')");
            System.out.println("Attraction created successfully!");
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 // resultSet.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }   
    }
       
    public static ArrayList allUsers() {
        ArrayList<String> allUsers = new ArrayList<String>();
        
       
        ResultSet resultSet = null;
        ResultSet res = null;
        
        try {
            connect = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            stm= connect.createStatement();
            resultSet = stm.executeQuery("select User_ID from user");
            while (resultSet.next()) {
                
                allUsers.add(resultSet.getString(1));
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                connect.close();
                stm.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        return allUsers;
    }
    
    public static ArrayList allAttractions() {
        ArrayList<String> allattractions = new ArrayList<String>();

        ResultSet resultSet = null;
        ResultSet res = null;
        
        try {
            connect = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            stm= connect.createStatement();
            resultSet = stm.executeQuery("select Attraction_Name from attractions where status='approved'");
            while (resultSet.next()) {
                
                allattractions.add(resultSet.getString(1));
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                connect.close();
                stm.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        return allattractions;
    }
    
    @Override
    public void Login(String id, String pwd){
        /* final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
            final String db_id = "kesaniv1536";
            final String db_psw = "1847246";
            Connection connection = null;
            Statement statement = null;*/
            ResultSet rs = null;
        try
        {
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            rs= statement.executeQuery("Select * from user where User_ID='"+id+"'");
            
            if(rs.next())
            {
                //the id is found, check the password
                if(pwd.equals(rs.getString("pwd")))
                {
                    //password is good
                    System.out.println("Welcome to your account " +id );
                    User.MainMenu(id);
                }
                else
                {
                    //password is not correct
                    // return "The password is not correct!";
                    System.out.println("Incorrect password");
                     
                }
            }
            else
            {
                // return "The login ID is not found!";
                System.out.println("User ID doesnot exists. Please enter correct ID or register if you are new.");
            }
        }
        catch (SQLException e)
        {
        System.out.println("Something wrong during the creation process!");
        e.printStackTrace();
        }
        finally
        {
        //close the database
        try
        {
            rs.close();
            statement.close();
            connection.close();
        }
         catch(Exception e)
         {
            e.printStackTrace();
         }
        }    
    }
    
    @Override
    public void displayUsers(){
        // final String DB_URL = "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536";
        /* final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
        final String db_id = "kesaniv1536";
        final String db_psw = "1847246";
        Connection connect = null;
        Statement statement = null;
        ResultSet resultSet = null;*/
        ResultSet dispusers = null;
        
        try {
            connection = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            statement= connection.createStatement();
            dispusers = statement.executeQuery("select User_ID from user");
            int i=1;
            while (dispusers.next()) {
                
                System.out.println("User "+ i +" "+dispusers.getString(1));
                i++;
                // allUsers.add(resultSet.getString(1));
                
                
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                dispusers.close();
                connection.close();
                statement.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void pendingAttractions(){
        /* final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
        final String db_id = "kesaniv1536";
        final String db_psw = "1847246";
        Connection connect = null;
        Statement statement = null;*/
        ResultSet pend_attr = null;
        try {
            connection = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            statement= connection.createStatement();
            pend_attr = statement.executeQuery("select Attraction_Name from attractions where Status = 'pending'");
            int i=1;
            while (pend_attr.next()) {
                
                System.out.println(i+ "." +pend_attr.getString(1));
                i++;   
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                pend_attr.close();
                connection.close();
                statement.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }  
    
    @Override
    public void approvedAttractions(){
        
        ResultSet approved_attr = null;
        try {
            connection = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            statement= connection.createStatement();
            approved_attr = statement.executeQuery("select Attraction_Name from attractions where Status = 'approved'");
            int i=1;
            while (approved_attr.next()) {  
                System.out.println(i+ "." +approved_attr.getString(1));
                i++;   
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                approved_attr.close();
                connection.close();
                statement.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void approve(String name){
        /* final String DATABASE_URL = 
                "jdbc:mysql://mis-sql.uhcl.edu/kesaniv1536?useSSL=false";
            final String db_id = "kesaniv1536";
            final String db_psw = "1847246";
            Connection connection = null;
            Statement statement = null;
            // ResultSet rs = null; */
        try
        {
            
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            /* int r = statement.executeUpdate("insert into attractions values" + "('" + name + "', '"
                        + "', '" + city + "', '" + state + "', '" + desc + "', '" + tag + "', '"
                        + tag +"', 0, 'Pending', " + user+ "')"); */
            int r = statement.executeUpdate("update attractions set Status = 'approved' where Attraction_Name = '" + name + "'");
            System.out.println("Attraction approved successfully!");
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 // resultSet.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    @Override
    public void search(String searchtag){
        ResultSet search_attr = null;
        
        try
        {
            
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
           
            // search_attr=statement.executeQuery("select * from attractions where Attraction_Name like'%" +searchtag + "%' or Tag like '%"+searchtag+"%' or State like '%"+searchtag+"%' or City like '%"+searchtag+"%' and Status = approved' order by Score");
            search_attr=statement.executeQuery("select * from attractions where (Status = 'approved') and (Attraction_Name like '%" + searchtag+ " %' or tag like '%" +searchtag+ "%' or City like '%" + searchtag+ "%' or State like '%" +searchtag+ "%' or tag like '%" +searchtag+ "%')  order by Score");
            int i=1;
            while (search_attr.next()) {    
                System.out.println( i +" "+search_attr.getString("Attraction_Name"));
                i++;
                // allUsers.add(resultSet.getString(1));
   
            }
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 search_attr.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    @Override
    public void displayattraction(String att_name, String user){
        Statement statement2=null;
        ResultSet att_details = null;
        ResultSet att_reviews = null;
        ArrayList<String> allAttr = allAttractions();
        
        for(String var:allAttr)
        {
            if(var.equals(att_name))
            {
                // Display Attraction
                try
                {
            
                    //connect to the databse
                    connection = DriverManager.getConnection(DATABASE_URL, 
                                        db_id, db_psw);
                    connection.setAutoCommit(false);
                    //crate the statement
                    statement = connection.createStatement();
                    // search_attr=statement.executeQuery("select * from attractions where Attraction_Name like'%" +searchtag + "%' or Tag like '%"+searchtag+"%' or State like '%"+searchtag+"%' or City like '%"+searchtag+"%' and Status = approved' order by Score");
                    att_details=statement.executeQuery("select * from attractions where Attraction_Name='" + att_name+ "'");
                    while (att_details.next()) {    
                        System.out.println("Name: "+ att_details.getString("Attraction_Name"));
                        System.out.println("Score: "+ att_details.getString("Score"));
                        System.out.println("Overview: "+ att_details.getString("Description"));
                        // allUsers.add(resultSet.getString(1));
                            
                    }
                    displayreviews(att_name);
                    System.out.println("1: To write a review about attracation");
                    System.out.println("2: To add this attraction to your favorite destinantions");
                    System.out.println("0: To go back to user menu");
                    String att_option = input.nextLine();
                    if(att_option.equals("1")){
                       Attraction.postreview(att_name, user);
                       User.MainMenu(user);
                     }   
                     else if(att_option.equals("2")){
                         // fav attractions
                         addfavattr(att_name,user);
                     }
                     else{
                         User.MainMenu(user);
                     }
                    System.out.println();
                    connection.commit();
                    connection.setAutoCommit(true);
            
                }
                catch (SQLException e)
                {
                    System.out.println("Something wrong during the creation process!");
                    e.printStackTrace();
                }
                finally
                {
                    //close the database
                    try
                    {
                        att_details.close();
                        att_reviews.close();
                        statement.close();
                        connection.close();    
                    }
                     catch(Exception e)
                    {
                         e.printStackTrace();
                    }
                }
                      
            }
            
                  
        }
        System.out.println();
        System.out.println("Please enter valid name or Use search option");
        System.out.println();
        User.MainMenu(user);
        
    }
    
    public static void displayreviews(String att_name){
        ResultSet att_reviews=null;
        
        try
        {
            
            //connect to the databse
            connect = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connect.setAutoCommit(false);
            //crate the statement
            stm = connect.createStatement();
            // search_attr=statement.executeQuery("select * from attractions where Attraction_Name like'%" +searchtag + "%' or Tag like '%"+searchtag+"%' or State like '%"+searchtag+"%' or City like '%"+searchtag+"%' and Status = approved' order by Score");
            att_reviews = stm.executeQuery("select * from review where Attraction_Name='" + att_name+ "'");
            System.out.println("*******Below are the reviews: *******");
            while(att_reviews.next()){
                
                System.out.println("User: "+att_reviews.getString("User_ID"));
                // System.out.println(""+att_reviews.getString("ID"));
                System.out.println("Score: "+att_reviews.getString("Score"));
                System.out.println("Comments: "+att_reviews.getString("Comments"));
                System.out.println("Date and Time: "+att_reviews.getString("Date and Time"));
                System.out.println("************************************************************");
             }
            System.out.println();
            connect.commit();
            connect.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 att_reviews.close();
                 stm.close();
                 connect.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    @Override
    public void postreview(String att_name, String user, float score, String comment, String date){
        Statement statement2 =null;
        Statement statement3 =null;
        Statement statement4=null;
        ResultSet review_num = null;
        ResultSet all_attr = null;
        ResultSet review_unique = null;
        try
        {
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            statement2 = connection.createStatement();
            statement3 = connection.createStatement();
            statement4 = connection.createStatement();
            
            all_attr = statement2.executeQuery("select * from attractions where Attraction_Name ='"+att_name+ "'");            
            
            review_unique = statement4.executeQuery("Select Attraction_Name, User_ID from review");
            
            // validating if the attraction is already reviewed by user
            boolean update = review_unique(att_name, user, review_unique);
            if(all_attr.next()){
                review_num=statement.executeQuery("select * from review");
                int nextNum = 1;
                String reviewNum = "";
                while(review_num.next())
                {
                    reviewNum = "" + review_num.getInt(1);
                    nextNum = review_num.getInt(1) + 1;
                 
                }
                if(update == true){
                    int r = statement.executeUpdate("insert into review values" + "('" +nextNum+ "', '" + att_name+ "', '" + user+ 
						"', '" +score+ "', '" +comment+ "', '" + date+ "')");
                    System.out.println("Review added successfuly");
                }
                else{
                    System.out.println("You have already reviewed this attraction!! ");
                    System.out.println("You cannot review an attraction twice");
                }
   
            }
            else
            {
                // return "The login ID is not found!";
                System.out.println("This attraction doesn't exixts. Please create attraction or enter correct name");
            }
 
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 review_num.close();
                 all_attr.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }     
    }
    
    public boolean review_unique(String att_name, String user, ResultSet review){
        
        boolean ans = true;
        try{
            while(review.next() && ans){
                if(((review.getString("User_ID")).equals(user)) && ((review.getString("Attraction_Name")).equals(att_name))){
                    ans = false;  
                }
            }
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong while adding to your favorite places");
            e.printStackTrace();
        }
        return ans;
    }
    
    @Override
    public void updatescore(float new_score, String att_name){
        
        ResultSet update_score = null;
        // float update_score;
        try
        {
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            
            update_score = statement.executeQuery("select score from attractions where Attraction_Name='" +att_name+"'");
            
            
            float last_score =0;
            while(update_score.next())
            {
                last_score = update_score.getFloat(1);     
            }
            float updated_score = (new_score+last_score)/2;
            int s = statement.executeUpdate("update attractions set score ='"+updated_score+"'where Attraction_Name='" +att_name+"'");
            
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the updation of score!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 update_score.close();
                 statement.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    @Override
    public void addfavattr(String att_name, String user){
        Statement statement_addfav = null;
        Connection connection_addfav = null;
        ResultSet fav_attr_unique = null;
        try
        {
            //connect to the databse
            connection_addfav = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection_addfav.setAutoCommit(false);
            //crate the statement
            statement_addfav = connection_addfav.createStatement();
            
            fav_attr_unique = statement_addfav.executeQuery("select * from fav_destination");
            
            // validating if this destination is already added to favorites for this user
            boolean update = fav_unique(att_name, user, fav_attr_unique);
            if(update == true){
                int r = statement_addfav.executeUpdate("insert into fav_destination values" + "('" +user+ "', '" + att_name+"')");
                System.out.println("Attraction added successfully to your favorite destinations");
                System.out.println();    
            }
            else{
                System.out.println("Attraction already added to your favorites");
            }
            User.MainMenu(user);

            connection_addfav.commit();
            connection_addfav.setAutoCommit(true); 
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong while adding to your favorite places");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 // resultSet.close();
                 statement_addfav.close();
                 connection_addfav.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
    
    public boolean fav_unique(String att_name, String user, ResultSet fav){
        
        boolean ans = true;
        try{
            while(fav.next() && ans){
                if(((fav.getString("User_ID")).equals(user)) && ((fav.getString("Attraction_Name")).equals(att_name))){
                    ans = false;  
                }
            }
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong while adding to your favorite places");
            e.printStackTrace();
        }
        return ans;
    }
    
    @Override
    public void displayfavattr(String user){
        ResultSet fav_attr = null;
        
        try {
            connection = DriverManager.getConnection(DATABASE_URL,db_id, db_psw);
            statement= connection.createStatement();
            fav_attr = statement.executeQuery("select * from fav_destination where User_ID='"+user+"'");
            System.out.println("Your favorite attractions are:");
            int i=1;
            while (fav_attr.next()) {
                
                System.out.println(""+ i +". "+fav_attr.getString(2));
                i++;
                // allUsers.add(resultSet.getString(1));
                
                
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally
        {
            //close the database
            try{
                fav_attr.close();
                connection.close();
                statement.close();
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void youmaylike(String user){
        Statement statement2=null;
        ResultSet fav_tags = null;
        ResultSet youmaylike = null;
        String fav_tag1="";
        String fav_tag2="";
        String fav_tag01="";
        String fav_tag02="";
        
        try
        {
            
            //connect to the databse
            connection = DriverManager.getConnection(DATABASE_URL, 
                    db_id, db_psw);
            connection.setAutoCommit(false);
            //crate the statement
            statement = connection.createStatement();
            statement2 = connection.createStatement();
            // search_attr=statement.executeQuery("select * from attractions where Attraction_Name like'%" +searchtag + "%' or Tag like '%"+searchtag+"%' or State like '%"+searchtag+"%' or City like '%"+searchtag+"%' and Status = approved' order by Score");
            
            fav_tags = statement.executeQuery("Select Tag1, Tag2 from user where User_ID='"+user+"'");
            
            while(fav_tags.next()){
                fav_tag1= fav_tags.getString("Tag1");
                fav_tag2 = fav_tags.getString("Tag2");
                // String fav_tag2 = fav_tags.getString("Tag2");
            }
            fav_tag01 = substr(fav_tag1,0,fav_tag1.indexOf(' '));
            fav_tag02 = substr(fav_tag2,0,fav_tag2.indexOf(' '));
            
            
            youmaylike = statement2.executeQuery("select Attraction_Name from attractions where tag ='"+fav_tag01+"' or tag='"+fav_tag02+"' order by score desc");
            
            int j=1;
            while((youmaylike.next()) && j<=3){
                System.out.println(" "+youmaylike.getString("Attraction_Name"));
                j++;
            }
            System.out.println();
            connection.commit();
            connection.setAutoCommit(true);
            
        }
        catch (SQLException e)
        {
            System.out.println("Something wrong during the creation process!");
            e.printStackTrace();
        }
        finally
        {
             //close the database
             try
             {
                 youmaylike.close();
                 fav_tags.close();
                 statement.close();
                 statement2.close();
                 connection.close();
             }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
        }
    }
   
}
